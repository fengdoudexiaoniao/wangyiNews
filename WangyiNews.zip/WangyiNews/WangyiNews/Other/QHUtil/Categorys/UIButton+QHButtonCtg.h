//
//  UIButton+QHButtonCtg.h
//  yimashuo
//
//  Created by imqiuhang on 15/8/17.
//  Copyright (c) 2015年 imqiuhang. All rights reserved.
//

#import "QHHead.h"

@interface UIButton (QHButtonCtg)


/**
 *  返回一个带有属性的按钮
 *
 *  @param aTitle    文本内容
 *  @param aFont     字体大小
 *  @param textColor 文本颜色
 *  @param bgColor   背景颜色
 *  @param radius    半径大小
 */
- (void)setTitle:(NSString *)aTitle andFont:(UIFont *)aFont andTitleColor:(UIColor *)textColor andBgColor:(UIColor *)bgColor andRadius:(float)radius;

@end
// 版权属于原作者
// http://code4app.com (cn) http://code4app.net (en)
// 发布代码于最专业的源码分享网站: Code4App.com