//
//  WgNetWorkTools.m
//  WangyiNews
//
//  Created by mac on 16/5/12.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "WgNetWorkTools.h"
static NSString * const NewsBaseURLString = @"http://c.m.163.com/nc/";
static WgNetWorkTools * _instance;

@implementation WgNetWorkTools

+(instancetype)shareNetWorkTool{

    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{

        _instance = [[self alloc] initWithBaseURL:[NSURL URLWithString:NewsBaseURLString]];


        //在这里就来处理那些坑
        _instance.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html", nil];
    });

    return _instance;
}


@end
