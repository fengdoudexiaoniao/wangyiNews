//
//  WgNetWorkTools.h
//  WangyiNews
//
//  Created by mac on 16/5/12.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"

@interface WgNetWorkTools : AFHTTPSessionManager

+(instancetype)shareNetWorkTool;


@end
