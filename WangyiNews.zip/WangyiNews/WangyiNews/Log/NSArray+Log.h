#import <Foundation/Foundation.h>

@interface NSArray (Log)

@end

@interface NSDictionary (Log)

@end