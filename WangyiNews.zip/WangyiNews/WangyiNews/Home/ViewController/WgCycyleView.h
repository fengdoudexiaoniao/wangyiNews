//
//  WgCycyleView.h
//  WangyiNews
//
//  Created by mac on 16/5/15.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WgCycyleView : UIView

@property(nonatomic,strong)NSArray *cycleArray;

@property(nonatomic,strong)UICollectionView *collectionView;

@end
