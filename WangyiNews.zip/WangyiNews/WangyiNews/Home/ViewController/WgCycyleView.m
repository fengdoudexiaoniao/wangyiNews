//
//  WgCycyleView.m
//  WangyiNews
//
//  Created by mac on 16/5/15.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "WgCycyleView.h"
#import "WgCycleCell.h"

@interface  WgCycyleView()<UICollectionViewDataSource,UICollectionViewDelegate>


@end

@implementation WgCycyleView{


    UICollectionViewFlowLayout *_flowLayout;
    UIPageControl *_pageControl;
}


-(instancetype)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];

    if (self) {

        [self setupUI];

    }

    return self;

}


-(void)setupUI{


    //无限循环
    _flowLayout = [[UICollectionViewFlowLayout alloc] init];

    _flowLayout.itemSize = self.frame.size;

    _flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;

    _flowLayout.minimumLineSpacing = 0;

    _flowLayout.minimumInteritemSpacing = 0;

    _collectionView = [[UICollectionView alloc] initWithFrame:self.bounds collectionViewLayout:_flowLayout];
    _pageControl = [[UIPageControl alloc] init];

    [self addSubview:_collectionView];
    [self addSubview:_pageControl];

    _collectionView.showsVerticalScrollIndicator = NO;
    _collectionView.showsHorizontalScrollIndicator = NO;
    _collectionView.bounces = NO;
    _collectionView.pagingEnabled = NO;

    _collectionView.delegate = self;
    _collectionView.dataSource = self;

    [_collectionView registerClass:[WgCycleCell class] forCellWithReuseIdentifier:@"ID"];

    [_pageControl mas_makeConstraints:^(MASConstraintMaker *make) {

        make.right.equalTo(self.mas_right);
        make.bottom.equalTo(self.mas_bottom).offset(-20);
        make.height.mas_equalTo(30);
        make.width.mas_equalTo(100);
    }];

    _pageControl.currentPage = 0;
    _pageControl.currentPageIndicatorTintColor = [UIColor redColor];


}



-(void)setCycleArray:(NSArray *)cycleArray{

    _cycleArray = cycleArray;
    _pageControl.numberOfPages = cycleArray.count;

    dispatch_async(dispatch_get_main_queue(), ^{

        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:cycleArray.count inSection:0];

        [_collectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
    });



}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{

    return self.cycleArray.count*100;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath;{

    WgCycleCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];

    cell.cycleModel = self.cycleArray[indexPath.item%self.cycleArray.count];

    _pageControl.currentPage = indexPath.item%self.cycleArray.count;

    return cell;

}


-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{

    NSInteger item = scrollView.contentOffset.x/self.bounds.size.width;


    if (item==0||item==self.cycleArray.count*100-1) {

        if (item==0) {

            item = self.cycleArray.count;

        }else{

            item = self.cycleArray.count-1;
        }

        [_collectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:item inSection:0] atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
        
    }
}








@end
