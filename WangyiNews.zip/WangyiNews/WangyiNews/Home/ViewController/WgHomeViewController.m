//
//  WgHomeViewController.m
//  WangyiNews
//
//  Created by mac on 16/5/11.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "WgHomeViewController.h"
#import "WgScrollView.h"
#import "WgContentViewController.h"
#import "WgTopicnewsModel.h"
#import "AFNetworking.h"
#import "WgNetWorkTools.h"
#import "ChannelLabel.h"

#define WgScrollViewHeight  44
#define COUNT 10
#define labelWidth 80
#define labelHeight 44

@interface WgHomeViewController ()<WgScrollViewDelegate,UICollectionViewDelegate>

@end

@implementation WgHomeViewController{

    NSMutableArray *_jsonDataArray;
    WgContentViewController *_contentVC;
    NSArray *_labels;
    WgScrollView *_scrollView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"网易新闻";
    self.view.backgroundColor = [UIColor purpleColor];

    [self getJsonData];
    [self createScrollView];
    [self addContentView];


}





-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

//标题
-(void)createScrollView{

    _scrollView = [[WgScrollView alloc] initWithFrame:CGRectMake(0, 64, screenWidth, WgScrollViewHeight)];
    [self.view addSubview:_scrollView];

    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.showsHorizontalScrollIndicator = NO;
    _scrollView.bounces = NO;
    _scrollView.contentSize = CGSizeMake(labelWidth*_jsonDataArray.count, -44);

    _scrollView.jsonDataArray = _jsonDataArray;

    _scrollView.delegates = self;

 
}


//内容视图
-(void)addContentView{


    _contentVC = [[WgContentViewController alloc] init];


    [self addChildViewController:_contentVC];

    [self.view addSubview:_contentVC.collectionView];

    _contentVC.collectionView.frame = CGRectMake(0, 108, screenWidth, screenHeight-108);

    _contentVC.JsonDataArray = _jsonDataArray;

    _contentVC.collectionView.delegate = self;


}



#pragma  mark 获取json数据
-(void)getJsonData{

    NSString *jsonStr = [[NSBundle mainBundle] pathForResource:@"topic_news.json" ofType:nil];

    NSData *jsonData = [[NSData alloc] initWithContentsOfFile:jsonStr];

    NSDictionary *JsonObject = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:nil];

    NSArray *dictArray = JsonObject[@"tList"];


    _jsonDataArray = [WgTopicnewsModel mj_objectArrayWithKeyValuesArray:dictArray];


    //6.对我们已经存在的`模型数组`,进行排序,排序的系统的API
    //根据tid的大小重新排位置

    [_jsonDataArray sortUsingComparator:^NSComparisonResult(WgTopicnewsModel * obj1,WgTopicnewsModel * obj2) {

      return [obj1.tid compare:obj2.tid];
    }];



}


#pragma mark WgScrollViewDelegate 代理方法
-(void)scrollViewDidClick:(WgScrollView *)scrollView scrollViewLabel:(UILabel *)scrollViewLabel{

    NSInteger index = scrollViewLabel.tag;

    //2.让下面的UICollection滚动到它该滚动的位置
    CGPoint collectionViewX = CGPointMake(index * _contentVC.collectionView.bounds.size.width, 0);

    [_contentVC.collectionView setContentOffset:collectionViewX animated:YES];

}

-(void)scrollViewDidClick:(WgScrollView *)scrollView labels:(NSMutableArray *)labels{

    NSLog(@"scrollViewDidClick%zd",labels.count);

    _labels = labels.copy;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    [self scrollViewDidEndScrollingAnimation:scrollView];
}


//#pragma mark 步骤3. 这个是上下联动的总方法,最终的这个方法
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView{
    //1.当前的索引
    NSInteger currentIndex = (int)scrollView.contentOffset.x / scrollView.bounds.size.width;

    NSLog(@"%zd",currentIndex);

    for (ChannelLabel *channelLabel in _labels) {
        if (channelLabel.tag == currentIndex) {//选中
            channelLabel.scale = 1.0;
        }else{
            channelLabel.scale = 0.0;
        }
    }

    //2.让我们的选中的channelLabel居中
    ChannelLabel *channelLabel = _labels[currentIndex];

    CGFloat needScrollX = channelLabel.center.x - _scrollView.bounds.size.width * 0.5;

    //2.1 最大允许滚出的x值
    CGFloat maxScrollX = _scrollView.contentSize.width - _scrollView.bounds.size.width;

    if (needScrollX < 0) {
        needScrollX = 0;
    }

    if (needScrollX > maxScrollX) {
        needScrollX = maxScrollX;
    }

    //通过这种方式来让其剧中
    [_scrollView setContentOffset:CGPointMake(needScrollX, -64) animated:YES];
}

/**
 左边的缩放比率和右边的缩放比率加起来 = 1，这个方法是在监视时时刻刻的滚动。
 */
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{

    //得到在第几页
    CGFloat value =  scrollView.contentOffset.x / scrollView.bounds.size.width;

    CGFloat maxScrollX = (_labels.count -1);

    if (value < 0) return;

    if (value > maxScrollX) return;

    //1.左边的索引
    NSInteger leftIndex = (int)scrollView.contentOffset.x / scrollView.bounds.size.width;

    //2.右边的索引
    NSInteger rightIndex = leftIndex + 1;

    //3.右边的缩放比率
    CGFloat rightScale = value - leftIndex;

    //4.左边的缩放比率
    CGFloat leftScale = 1 - rightScale;

    //NSLog(@"%f---%f",leftScale,rightScale);
    //5.分别去得左边,右边索引对应的ChannelLabel,给其设置缩放值
    ChannelLabel *leftChannelLabel = _labels[leftIndex];
    leftChannelLabel.scale = leftScale;

    if (rightIndex < _labels.count) {
        ChannelLabel *rightChannelLabel = _labels[rightIndex];
        rightChannelLabel.scale = rightScale;
    }
}




@end
























