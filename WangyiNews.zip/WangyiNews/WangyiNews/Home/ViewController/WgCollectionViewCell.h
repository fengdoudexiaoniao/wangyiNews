//
//  WgCollectionViewCell.h
//  WangyiNews
//
//  Created by mac on 16/5/12.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WgTopicnewsModel.h"

@interface WgCollectionViewCell : UICollectionViewCell

@property(nonatomic,strong)WgTopicnewsModel *topicModel;

@end
