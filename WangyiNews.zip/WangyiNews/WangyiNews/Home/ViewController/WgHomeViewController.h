//
//  WgHomeViewController.h
//  WangyiNews
//
//  Created by mac on 16/5/11.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WgHomeViewController : UIViewController

@end
