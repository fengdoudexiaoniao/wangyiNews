//
//  WgContentViewController.m
//  WangyiNews
//
//  Created by mac on 16/5/11.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "WgContentViewController.h"
#import "QHHead.h"
#import "WgCollectionViewCell.h"
#import "WgTopicnewsModel.h"

@interface WgContentViewController ()

@end

@implementation WgContentViewController{

    UICollectionViewFlowLayout *_flowLayout;

}

static NSString * const reuseIdentifier = @"Cell";

- (void)viewDidLoad {
    [super viewDidLoad];

    [self.collectionView registerClass:[WgCollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];

    self.collectionView.bounces = NO;

}


- (instancetype)init
{

    _flowLayout = [[UICollectionViewFlowLayout alloc] init];

    _flowLayout.itemSize = CGSizeMake(screenWidth, screenHeight-108);
    _flowLayout.minimumLineSpacing = 0;
    _flowLayout.minimumInteritemSpacing = 0;
    _flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;


    self = [super init];
    if (self) {

        self = [self initWithCollectionViewLayout:_flowLayout];

        self.collectionView.showsHorizontalScrollIndicator = NO;
        self.collectionView.showsVerticalScrollIndicator = NO;

        self.collectionView.pagingEnabled = YES;

     }
    return self;
}



-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{


    return self.JsonDataArray.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{

    WgCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];

    cell.backgroundColor = [UIColor colorWithRed:arc4random_uniform(256)/255.0 green:arc4random_uniform(256)/255.0 blue:arc4random_uniform(256)/255.0 alpha:1.0];

    WgTopicnewsModel *model = self.JsonDataArray[indexPath.item];

    cell.topicModel = model;

    return cell;
}











@end
