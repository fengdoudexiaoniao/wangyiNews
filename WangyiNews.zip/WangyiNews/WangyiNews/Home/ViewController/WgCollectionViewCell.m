//
//  WgCollectionViewCell.m
//  WangyiNews
//
//  Created by mac on 16/5/12.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "WgCollectionViewCell.h"
#import "WgNetWorkTools.h"
#import "WgNewModel.h"
#import "WgOnePictureCell.h"
#import "WgSecondPictureCell.h"
#import "WgThirdCell.h"
#import "WgCycyleView.h"
#import "WgCycleModel.h"

@interface WgCollectionViewCell()<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,strong)NSArray *newsModelArray;

@end

@implementation WgCollectionViewCell{

    UITableView *_tableView;

    WgCycyleView *_cycleView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

        [self setupUI];

        [self getCycleDatas];


    }
    return self;
}


-(void)setupUI{

    _tableView = [[UITableView alloc] init];

    _tableView.delegate = self;

    _tableView.dataSource = self;

    [self addSubview:_tableView];

    _tableView.frame = self.bounds;

    _tableView.backgroundColor = [UIColor orangeColor];

    [_tableView registerClass:[WgOnePictureCell class] forCellReuseIdentifier:@"base"];
    [_tableView registerClass:[WgSecondPictureCell class] forCellReuseIdentifier:@"big"];
    [_tableView registerClass:[WgThirdCell class] forCellReuseIdentifier:@"three"];

    _cycleView = [[WgCycyleView alloc] initWithFrame:CGRectMake(0, 0, screenWidth, 200)];
    _tableView.tableHeaderView = _cycleView;




}


-(void)setTopicModel:(WgTopicnewsModel *)topicModel{

    _topicModel = topicModel;

    //请求网络数据

    WgNetWorkTools *netWorkTools = [WgNetWorkTools shareNetWorkTool];

    __weak typeof(self) WeakSelf = self;
    [netWorkTools GET:topicModel.URLString parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary * responseObject) {

        NSArray *dictArray = responseObject[topicModel.tid];

        WeakSelf.newsModelArray = [WgNewModel mj_objectArrayWithKeyValuesArray:dictArray];

        [_tableView reloadData];


    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        
    }];


}

#pragma mark 请求无限循环数据
-(void)getCycleDatas{

    //请求网络数据

    WgNetWorkTools *netWorkTools = [WgNetWorkTools shareNetWorkTool];
    
    [netWorkTools GET:@"ad/headline/0-4.html" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary * responseObject) {

        NSArray *dictArray = responseObject[@"headline_ad"];

        NSArray *cycleArray = [WgCycleModel mj_objectArrayWithKeyValuesArray:dictArray];

        _cycleView.cycleArray = cycleArray;

        [_cycleView.collectionView reloadData];
        

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {


    }];
}

#pragma mark UITableDataSource

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{


    return self.newsModelArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{


    static NSString *ID;

    WgNewModel *newsmodel = self.newsModelArray[indexPath.row];

    if (newsmodel.imgType) {

        ID = @"big";

        WgSecondPictureCell *cell = [tableView dequeueReusableCellWithIdentifier:ID forIndexPath:indexPath];

        cell.newsModel = newsmodel;

        return cell;


    }else if (newsmodel.imgextra.count == 2){

        ID = @"three";

        WgThirdCell *cell = [tableView dequeueReusableCellWithIdentifier:ID forIndexPath:indexPath];

        cell.newsModel = newsmodel;

        return cell;


    }else{

        ID = @"base";


        WgOnePictureCell *cell = [tableView dequeueReusableCellWithIdentifier:ID forIndexPath:indexPath];

        cell.newsModel = newsmodel;

        return cell;

    }

}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{


    WgNewModel *newsmodel = self.newsModelArray[indexPath.row];

    if (newsmodel.imgType) {

        return 180;
    }else if (newsmodel.imgextra.count == 2){

        return 120;
    }else{

        return 80;
    }

}







@end
