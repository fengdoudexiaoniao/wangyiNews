//
//  WgTopicnewsModel.h
//  WangyiNews
//
//  Created by mac on 16/5/12.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WgTopicnewsModel : NSObject

//tname = 原创;
//color = ;
//subnum = 6.8万;
//isHot = 1;
//tid = T1370583240249;
//img = http://img2.cache.netease.com/m/newsapp/banner/zhenhua.png;

@property(nonatomic,copy)NSString *tname;
@property(nonatomic,copy)NSString *tid;

@property(nonatomic,copy)NSString *URLString;

@end
