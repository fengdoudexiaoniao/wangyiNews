//
//  WgNewModel.m
//  WangyiNews
//
//  Created by mac on 16/5/14.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "WgNewModel.h"
#import "WgimgsrcModel.h"

@implementation WgNewModel

/**
 *  数组中需要转换的模型类
 *
 *  @return 字典中的key是数组属性名，value是数组中存放模型的Class（Class类型或者NSString类型）
 */
+ (NSDictionary *)mj_objectClassInArray{

    return @{@"imgextra":[WgimgsrcModel class]};
}
@end
