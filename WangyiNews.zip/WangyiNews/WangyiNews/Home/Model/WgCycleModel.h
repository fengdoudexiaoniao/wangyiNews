//
//  WgCycleModel.h
//  WangyiNews
//
//  Created by mac on 16/5/15.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WgCycleModel : NSObject

//新闻标题
@property(nonatomic,copy)NSString *title;

//图片网址
@property(nonatomic,copy)NSString *imgsrc;


@end
