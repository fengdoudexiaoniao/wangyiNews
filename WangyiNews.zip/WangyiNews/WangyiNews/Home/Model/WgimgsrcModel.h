//
//  WgimgsrcModel.h
//  WangyiNews
//
//  Created by mac on 16/5/14.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WgimgsrcModel : NSObject

@property(nonatomic,copy)NSString *imgsrc;

@end
