//
//  WgCycleModel.m
//  WangyiNews
//
//  Created by mac on 16/5/15.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "WgCycleModel.h"

@implementation WgCycleModel

@end
