//
//  WgimgsrcModel.m
//  WangyiNews
//
//  Created by mac on 16/5/14.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "WgimgsrcModel.h"

@implementation WgimgsrcModel

@end
