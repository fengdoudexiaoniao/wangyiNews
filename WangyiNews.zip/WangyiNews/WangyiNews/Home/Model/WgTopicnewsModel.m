//
//  WgTopicnewsModel.m
//  WangyiNews
//
//  Created by mac on 16/5/12.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "WgTopicnewsModel.h"

@implementation WgTopicnewsModel


-(void)setTid:(NSString *)tid{

    _tid = tid;

    _URLString = [NSString stringWithFormat:@"article/headline/%@/0-40.html",_tid];

}


@end
