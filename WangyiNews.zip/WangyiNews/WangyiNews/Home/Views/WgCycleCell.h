//
//  WgCycleCell.h
//  WangyiNews
//
//  Created by mac on 16/5/15.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WgCycleModel.h"

@interface WgCycleCell : UICollectionViewCell

@property(nonatomic,strong)WgCycleModel *cycleModel;

@end
