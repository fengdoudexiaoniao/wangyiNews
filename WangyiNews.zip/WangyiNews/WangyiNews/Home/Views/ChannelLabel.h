//
//  ChannelLabel.h
//  NewsBoard
//
//  Created by Apple on 15/12/19.
//  Copyright © 2015年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChannelLabel : UILabel

/**
    这个ChannelLabel缩放值 是从0-1 ,当显示红色的时候,就是1,当显示黑色的时候,就是0
 */
@property(nonatomic,assign)CGFloat scale;

@end
