//
//  WgScrollView.m
//  WangyiNews
//
//  Created by mac on 16/5/11.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "WgScrollView.h"
#import "WgTopicnewsModel.h"
#import "ChannelLabel.h"
#define labelWidth 80
#define labelHeight 44

@implementation WgScrollView{

    NSMutableArray *_tempLabels;
}


-(instancetype)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];

    if (self) {

        self.backgroundColor = [UIColor purpleColor];

        _tempLabels = [NSMutableArray array];

    }

    return self;
}


/**
 *  循环创建label
 */

-(void)setJsonDataArray:(NSArray *)jsonDataArray{

    _jsonDataArray = jsonDataArray;

    NSLog(@"%zd",_jsonDataArray.count);
    for (int i=0; i<self.jsonDataArray.count; i++) {

        WgTopicnewsModel *model = self.jsonDataArray[i];

        ChannelLabel *titleLabel = [[ChannelLabel alloc] init];
        [titleLabel setText:model.tname andFont:[UIFont systemFontOfSize:16] andTextColor:[UIColor blueColor]];
        [self addSubview:titleLabel];

        titleLabel.tag = i;

        titleLabel.frame = CGRectMake(labelWidth*i, -64, labelWidth, labelHeight);
        titleLabel.textAlignment = NSTextAlignmentCenter;

        titleLabel.userInteractionEnabled = YES;

        UITapGestureRecognizer *gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(titleLabelClick:)];

        [titleLabel addGestureRecognizer:gesture];

        [_tempLabels addObject:titleLabel];

    }



}


-(void)titleLabelClick:(UIGestureRecognizer *)gesture{

    ChannelLabel *label =(ChannelLabel *)gesture.view;

//    NSLog(@"%zd",label.tag);

    if ([self.delegates respondsToSelector:@selector(scrollViewDidClick:scrollViewLabel:)]) {

        [self.delegates scrollViewDidClick:self scrollViewLabel:label];
    }

    if ([self.delegates respondsToSelector:@selector(scrollViewDidClick:labels:)]) {

        [self.delegates scrollViewDidClick:self labels:_tempLabels];
    }

}




@end

















