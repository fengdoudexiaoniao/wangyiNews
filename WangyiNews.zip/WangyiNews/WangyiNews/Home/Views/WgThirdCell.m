//
//  WgThirdCell.m
//  WangyiNews
//
//  Created by mac on 16/5/14.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "WgThirdCell.h"
#import "WgimgsrcModel.h"

@implementation WgThirdCell{

    UILabel *_titleLabel;
    UIImageView *_iconViewfirst;
    UIImageView *_iconViewSecond;
    UIImageView *_iconViewThree;
    UILabel *_countLabel;

}


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{

    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];

    if (self) {

        [self setUpUI];
    }

    return self;
}
-(void)setUpUI{
    _titleLabel = [[UILabel alloc] init];
    _iconViewfirst = [[UIImageView alloc] init];
    _iconViewSecond = [[UIImageView alloc] init];
    _iconViewThree = [[UIImageView alloc]init];
    _countLabel = [[UILabel alloc] init];
    [_titleLabel setText:@"标题" andFont:[UIFont systemFontOfSize:16] andTextColor:[UIColor blackColor]];
    [_countLabel setText:@"数量" andFont:[UIFont systemFontOfSize:12] andTextColor:[UIColor grayColor]];
    [self addSubview:_titleLabel];
    [self addSubview:_iconViewfirst];
    [self addSubview:_iconViewThree];
    [self addSubview:_iconViewSecond];
    [self addSubview:_countLabel];

    _iconViewfirst.backgroundColor = [UIColor redColor];
    _iconViewSecond.backgroundColor = [UIColor greenColor];
    _iconViewThree.backgroundColor = [UIColor blueColor];

    CGFloat pictureWidth = (screenWidth-5*4)/3;

    [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {

        make.left.equalTo(self.mas_left).offset(10);
        make.top.equalTo(self.mas_top).offset(10);

    }];

    [_countLabel mas_makeConstraints:^(MASConstraintMaker *make) {

        make.right.equalTo(self.mas_right).offset(-10);
        make.top.equalTo(self.mas_top).offset(10);

    }];

    [_iconViewfirst mas_makeConstraints:^(MASConstraintMaker *make) {

        make.left.equalTo(self.mas_left).offset(5);
        make.top.equalTo(_titleLabel.mas_bottom).offset(5);
        make.bottom.equalTo(self.mas_bottom).offset(-5);
        make.right.equalTo(_iconViewSecond.mas_left).offset(-5);

        make.width.mas_equalTo(pictureWidth);
    }];
    [_iconViewSecond mas_makeConstraints:^(MASConstraintMaker *make) {

        make.left.equalTo(_iconViewfirst.mas_right).offset(5);
        make.bottom.top.width.equalTo(_iconViewfirst);
        make.right.equalTo(_iconViewThree.mas_left).offset(-5);

    }];
    [_iconViewThree mas_makeConstraints:^(MASConstraintMaker *make) {

        make.left.equalTo(_iconViewSecond.mas_right).offset(5);
        make.bottom.top.width.equalTo(_iconViewSecond);
    }];

}



-(void)setNewsModel:(WgNewModel *)newsModel{

    _newsModel = newsModel;

    [_titleLabel setText:newsModel.title];

    [_countLabel setText:[NSString stringWithFormat:@"%zd",newsModel.replyCount]];

    [_iconViewfirst sd_setImageWithURL:[NSURL URLWithString:newsModel.imgsrc]];

    for (int i=0; i<newsModel.imgextra.count; i++) {
         WgimgsrcModel *imageModel = newsModel.imgextra[i];
        if (i==0) {

            [_iconViewSecond sd_setImageWithURL:[NSURL URLWithString:imageModel.imgsrc]];

        }else{

            [_iconViewThree sd_setImageWithURL:[NSURL URLWithString:imageModel.imgsrc]];
        }
    }

}










@end
