//
//  WgScrollView.h
//  WangyiNews
//
//  Created by mac on 16/5/11.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WgScrollView;

@protocol WgScrollViewDelegate <NSObject>

-(void)scrollViewDidClick:(WgScrollView *)scrollView scrollViewLabel:(UILabel *)scrollViewLabel;

-(void)scrollViewDidClick:(WgScrollView *)scrollView labels:(NSMutableArray *)labels;

@end

@interface WgScrollView : UIScrollView

@property(nonatomic,strong)NSArray *jsonDataArray;

@property(nonatomic,weak)id<WgScrollViewDelegate>delegates;


@end
