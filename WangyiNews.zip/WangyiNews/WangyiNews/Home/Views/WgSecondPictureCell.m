//
//  WgSecondPictureCell.m
//  WangyiNews
//
//  Created by mac on 16/5/14.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "WgSecondPictureCell.h"

@implementation WgSecondPictureCell{

    UILabel *_titleLabel;
    UILabel *_contentLabel;
    UILabel *_countLabel;
    UIImageView *_imageView;

}



-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{

    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];

    if (self) {

    self.backgroundColor = [UIColor redColor];

        [self setUpUI];
    }

    return self;
}
-(void)setUpUI{

    _titleLabel = [[UILabel alloc] init];
    _contentLabel = [[UILabel alloc] init];
    _countLabel = [[UILabel alloc] init];
    _imageView = [[UIImageView alloc] init];

    [self addSubview:_titleLabel];
    [self addSubview:_contentLabel];
    [self addSubview:_countLabel];
    [self addSubview:_imageView];

    [_titleLabel setText:@"习近平对高级干部说那些不" andFont:[UIFont systemFontOfSize:16] andTextColor:[UIColor blackColor]];
    [_contentLabel setText:@"习近平对高级干部说那些不" andFont:[UIFont systemFontOfSize:12] andTextColor:[UIColor grayColor]];
    [_countLabel setText:@"6666" andFont:[UIFont systemFontOfSize:12] andTextColor:[UIColor grayColor]];

    [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {

        make.left.equalTo(self.mas_left).offset(10);
        make.top.equalTo(self.mas_top).offset(10);
    }];


    [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {

        make.left.equalTo(self.mas_left).offset(10);
        make.right.equalTo(self.mas_right).offset(-10);
        make.bottom.equalTo(self.mas_bottom).offset(-5);
        make.top.equalTo(self.mas_top).offset(5);
    }];

    [_contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {

        make.left.equalTo(self.mas_left).offset(10);
        make.top.equalTo(_imageView.mas_bottom).offset(10);
        make.bottom.equalTo(self.mas_bottom).offset(-5);
    }];

    [_countLabel mas_makeConstraints:^(MASConstraintMaker *make) {

        make.left.equalTo(self.mas_left).offset(-5);
        make.top.equalTo(_imageView.mas_bottom).offset(-10);

    }];
}













@end
