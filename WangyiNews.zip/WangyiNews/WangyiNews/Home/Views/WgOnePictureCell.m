//
//  WgOnePictureCell.m
//  WangyiNews
//
//  Created by mac on 16/5/14.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "WgOnePictureCell.h"

@implementation WgOnePictureCell{

    UIImageView *_iconImageView;
    UILabel *_titleLabel;
    UILabel *_contentLabel;
    UILabel *_countLabel;
}



-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{

    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];

    if (self) {

        [self setUpUI];
    }

    return self;
}

-(void)setUpUI{

    _iconImageView = [[UIImageView alloc] init];
    _titleLabel = [[UILabel alloc] init];
    _contentLabel = [[UILabel alloc] init];
    _countLabel = [[UILabel alloc] init];

    [self addSubview:_iconImageView];
    [self addSubview:_titleLabel];
    [self addSubview:_contentLabel];
    [self addSubview:_countLabel];

    _iconImageView.backgroundColor = [UIColor redColor];

    [_titleLabel setText:@"习近平对高级干部说那些不" andFont:[UIFont systemFontOfSize:16]andTextColor:[UIColor blackColor]];
    [_contentLabel setText:@"习近平对高级干部说那些不习近平对高级干部说那些不习近平对高级干部说那些不习近平对高级干部说那些不习近平对高级干部说那些不" andFont:[UIFont systemFontOfSize:14] andTextColor:[UIColor grayColor]];
    [_countLabel setText:@"6666" andFont:[UIFont systemFontOfSize:16] andTextColor:[UIColor grayColor]];
    _contentLabel.numberOfLines = 0;

    [_iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {

        make.left.top.equalTo(self).offset(5);
        make.bottom.equalTo(self).offset(-5);
        make.width.mas_equalTo(80);
    }];


    [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {

        make.left.equalTo(_iconImageView.mas_right).offset(5);
        make.top.equalTo(self.mas_top).offset(5);
    }];

    [_contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {

        make.left.equalTo(_iconImageView.mas_right).offset(5);
        make.top.equalTo(_titleLabel.mas_bottom).offset(5);
        make.width.mas_equalTo(self.width-_iconImageView.width-10);
    }];

    [_countLabel mas_makeConstraints:^(MASConstraintMaker *make) {

        make.right.equalTo(self.mas_right);
        make.bottom.equalTo(self.mas_bottom);
    }];
}



-(void)setNewsModel:(WgNewModel *)newsModel{

    _newsModel = newsModel;

    [_iconImageView sd_setImageWithURL:[NSURL URLWithString:newsModel.imgsrc]];

    [_titleLabel setText:newsModel.title];

    [_contentLabel setText:newsModel.digest];

    [_countLabel setText:[NSString stringWithFormat:@"%zd",newsModel.replyCount]];

}









@end
