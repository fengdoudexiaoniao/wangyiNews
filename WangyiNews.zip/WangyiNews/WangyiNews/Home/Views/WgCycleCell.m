//
//  WgCycleCell.m
//  WangyiNews
//
//  Created by mac on 16/5/15.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import "WgCycleCell.h"

@implementation WgCycleCell{

    UILabel *_titleLabel;
    UIImageView *_iconView;
}


-(instancetype)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];

    if (self) {

        [self setupUI];

        self.backgroundColor = [UIColor whiteColor];

    }

    return self;
}


-(void)setupUI{
    //标题
    _titleLabel = [[UILabel alloc] init];
    _iconView = [[UIImageView alloc] init];

    [self addSubview:_titleLabel];
    [self addSubview:_iconView];
    [_titleLabel setText:@"中国特警平板支撑超过8小时破纪录" andFont:[UIFont systemFontOfSize:16] andTextColor:[UIColor blackColor]];

    [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {

        make.left.bottom.equalTo(self);
        make.height.equalTo(@20);

    }];

    //图片
     [_iconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.equalTo(self);

        make.bottom.equalTo(_titleLabel.mas_top);
    }];



}



-(void)setCycleModel:(WgCycleModel *)cycleModel{

    _cycleModel = cycleModel;
    [_titleLabel setText:cycleModel.title];
    [_iconView sd_setImageWithURL:[NSURL URLWithString:cycleModel.imgsrc]];
    
}



















@end
