//
//  ChannelLabel.m
//  NewsBoard
//
//  Created by Apple on 15/12/19.
//  Copyright © 2015年 itcast. All rights reserved.
//

#import "ChannelLabel.h"

@implementation ChannelLabel

- (instancetype)initWithFrame:(CGRect)frame{
    if (self=[super initWithFrame:frame]) {
        //做一些初始化的工作
        self.textAlignment = NSTextAlignmentCenter;
        
//        self.backgroundColor = [UIColor colorWithRed:((float)arc4random_uniform(256) / 255.0) green:((float)arc4random_uniform(256) / 255.0) blue:((float)arc4random_uniform(256) / 255.0) alpha:1.0];
        
        self.font = [UIFont systemFontOfSize:20];
        
#warning  默认情况下,我让所有的缩放比率都是0
        self.scale = 0;
    }
    
    return self;
}

- (void)setScale:(CGFloat)scale{
    _scale = scale;
    
    //1.设置颜色的渐变
    self.textColor = [UIColor colorWithRed:scale green:0 blue:0 alpha:1.0];
    
    CGFloat minSacle = 0.8;
    
    /**
        让其缩放比率在0.8-1.0之间
     */
    scale = minSacle + (1 - minSacle) *scale;
    
    //2.设置transform的scale
    self.transform = CGAffineTransformMakeScale(scale, scale);
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
