//
//  WgSecondPictureCell.h
//  WangyiNews
//
//  Created by mac on 16/5/14.
//  Copyright © 2016年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WgNewModel.h"

@interface WgSecondPictureCell : UITableViewCell

@property(nonatomic,strong)WgNewModel *newsModel;


@end
